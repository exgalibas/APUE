//
//  main.c
//  apue
//
//  Created by didi on 2018/11/13.
//  Copyright © 2018 didi. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;

}