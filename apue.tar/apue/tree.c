#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include "apue.h"

#define DEPTH 2

int tree(char *);

int
main(int argc, char *argv[])
{
    if (argc != 2) {
        err_quit("usage: tree directory_name");
    }

    tree(argv[1]);
}

int
tree(char *dir)
{
    static int depth = 0;
    char *tempDir;
    size_t length;

    if (depth >= DEPTH) {
        return 0;
    }

    DIR             *dp;
    struct dirent   *dirp;

    if ((dp = opendir(dir)) == NULL)
        err_sys("car`t open %s", *dir);

    length = strlen(dir) + 1;
    tempDir = (char *) malloc(length);
    memcpy(tempDir, dir, length);

    while ((dirp = readdir(dp)) != NULL) {
        for (int i = 0; i < depth; i++) {
            printf("|");
            printf("    ");
        }
        printf ("|--- %s\n", dirp->d_name);
        if (dirp->d_type == DT_DIR &&
            strcmp(dirp->d_name, ".") != 0 &&
            strcmp(dirp->d_name, "..")) {
            depth++;
            strcat(dir, "/");
            strcat(dir, dirp->d_name);
            tree(dir);
            memcpy(dir, tempDir, length);
            depth--;
        }
    }

    free(tempDir);
    closedir(dp);
    return 0;
}